// Version information for the "groupsock" library
// Copyright (c) 1996-2016 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2016.10.11"
#define GROUPSOCK_LIBRARY_VERSION_INT		1476144000

#endif
